package com.example.contact.controller;

import com.example.contact.model.Contact;
import com.example.contact.service.ContactService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contacts")
@CrossOrigin(origins = "*")
public class ContactController {

    private final ContactService service;

    public ContactController(ContactService service) {
        this.service = service;
    }

    // POST /contacts
    @PostMapping
    public Contact createContact(@RequestBody Contact contact) {
        return service.addContact(contact);
    }

    // GET /contacts
    @GetMapping
    public List<Contact> getAllContacts() {
        return service.getAllContacts();
    }

    // PUT /contacts/{id}
    @PutMapping("/{id}")
    public Contact updateContact(@PathVariable Long id,
                                 @RequestBody Contact contact) {
        return service.updateContact(id, contact);
    }

    // DELETE /contacts/{id}
    @DeleteMapping("/{id}")
    public String deleteContact(@PathVariable Long id) {
        service.deleteContact(id);
        return "Contact deleted successfully";
    }
}
