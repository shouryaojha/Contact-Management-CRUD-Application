package com.example.contact.repository;

import com.example.contact.model.Contact;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ContactRepository {

    private final Map<Long, Contact> contactStore = new HashMap<>();
    private Long idCounter = 1L;

    public Contact save(Contact contact) {
        contact.setId(idCounter++);
        contactStore.put(contact.getId(), contact);
        return contact;
    }

    public List<Contact> findAll() {
        return new ArrayList<>(contactStore.values());
    }

    public Contact update(Long id, Contact contact) {
        contact.setId(id);
        contactStore.put(id, contact);
        return contact;
    }

    public void delete(Long id) {
        contactStore.remove(id);
    }
}
