package com.example.contact.service;

import com.example.contact.model.Contact;
import com.example.contact.repository.ContactRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactService {

    private final ContactRepository repository;

    public ContactService(ContactRepository repository) {
        this.repository = repository;
    }

    public Contact addContact(Contact contact) {
        return repository.save(contact);
    }

    public List<Contact> getAllContacts() {
        return repository.findAll();
    }

    public Contact updateContact(Long id, Contact contact) {
        return repository.update(id, contact);
    }

    public void deleteContact(Long id) {
        repository.delete(id);
    }
}
