const API_URL = "http://localhost:8082/contacts";

function loadContacts() {
    fetch(API_URL)
        .then(res => res.json())
        .then(data => {
            let rows = "";
            data.forEach(c => {
                rows += `
                    <tr>
                        <td>${c.id}</td>
                        <td>${c.name}</td>
                        <td>${c.phone}</td>
                        <td>
                            <button class="edit" onclick="editContact(${c.id}, '${c.name}', '${c.phone}')">Edit</button>
                            <button class="delete" onclick="deleteContact(${c.id})">Delete</button>
                        </td>
                    </tr>
                `;
            });
            document.getElementById("contactTable").innerHTML = rows;
        });
}

function saveContact() {
    const id = document.getElementById("contactId").value;
    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();

    if (!name || !phone) {
        alert("Please fill all fields");
        return;
    }

    const method = id ? "PUT" : "POST";
    const url = id ? `${API_URL}/${id}` : API_URL;

    fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone })
    }).then(() => {
        resetForm();
        loadContacts();
    });
}

function editContact(id, name, phone) {
    document.getElementById("contactId").value = id;
    document.getElementById("name").value = name;
    document.getElementById("phone").value = phone;
    document.getElementById("saveBtn").innerText = "Update Contact";
}

function deleteContact(id) {
    fetch(`${API_URL}/${id}`, { method: "DELETE" })
        .then(() => loadContacts());
}

function resetForm() {
    document.getElementById("contactId").value = "";
    document.getElementById("name").value = "";
    document.getElementById("phone").value = "";
    document.getElementById("saveBtn").innerText = "Add Contact";
}

// Load on page start
loadContacts();
