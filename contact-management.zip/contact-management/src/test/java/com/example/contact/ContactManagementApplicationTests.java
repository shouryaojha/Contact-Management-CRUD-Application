package com.example.contact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
